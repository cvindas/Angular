export const environment = {
  production: true,
  firebase: {
    //firebase settings
  }
};
