export interface Product {
  id?: string;
  name?: string;
  description?: string;
  price?: number;
}

// export class Product {
//   constructor(
//     public id?: string,
//     public description?: string,
//     public name?: string,
//     public price: number = 0
//   ) {}
// }