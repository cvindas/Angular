export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCnrm93axlwbHzXEVA8smrQVw-i3OJMoEY",
    authDomain: "loginapp-c7ad7.firebaseapp.com",
    databaseURL: "https://loginapp-c7ad7.firebaseio.com",
    projectId: "loginapp-c7ad7",
    storageBucket: "loginapp-c7ad7.appspot.com",
    messagingSenderId: "185540221956"
  }
};
