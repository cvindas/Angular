export interface Photo {
    _id?: string;
    title: String;
    description: String;
    imagePath: string;
}